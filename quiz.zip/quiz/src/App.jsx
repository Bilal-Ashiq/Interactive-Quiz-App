import { useState, useEffect } from 'react';
import { questions } from './data/questions.js';
import { shuffleArray } from './utils/shuffle.js';
import Home from './components/Home.jsx';
import Quiz from './components/Quiz.jsx';
import Result from './components/Result.jsx';
import Leaderboard from './components/Leaderboard.jsx';
import './styles/App.css';

function App() {
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  const [currentScreen, setCurrentScreen] = useState('home');
  const [quizData, setQuizData] = useState({
    category: '',
    difficulty: '',
    questions: [],
    currentQuestionIndex: 0,
    score: 0,
    timeLeft: 0,
    selectedAnswer: null,
    showResult: false
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const startQuiz = (category, difficulty) => {
    const categoryQuestions = questions[category];
    const shuffledQuestions = shuffleArray(categoryQuestions).slice(0, 10); // Take 10 questions
    const questionsWithShuffledOptions = shuffledQuestions.map(q => {
      const shuffledOptions = shuffleArray([...q.options]);
      const correctIndex = shuffledOptions.indexOf(q.options[q.correct]);
      return {
        ...q,
        options: shuffledOptions,
        correct: correctIndex
      };
    });

    setQuizData({
      category,
      difficulty,
      questions: questionsWithShuffledOptions,
      currentQuestionIndex: 0,
      score: 0,
      timeLeft: getTimeForDifficulty(difficulty),
      selectedAnswer: null,
      showResult: false
    });
    setCurrentScreen('quiz');
  };

  const getTimeForDifficulty = (difficulty) => {
    switch (difficulty) {
      case 'Easy': return 20;
      case 'Medium': return 15;
      case 'Hard': return 10;
      default: return 20;
    }
  };

  const handleAnswerSelect = (answerIndex) => {
    const currentQuestion = quizData.questions[quizData.currentQuestionIndex];
    const isCorrect = answerIndex === currentQuestion.correct;

    setQuizData(prev => ({
      ...prev,
      selectedAnswer: answerIndex,
      score: isCorrect ? prev.score + 1 : prev.score,
      showResult: true
    }));

    setTimeout(() => {
      nextQuestion();
    }, 2000);
  };

  const nextQuestion = () => {
    if (quizData.currentQuestionIndex < quizData.questions.length - 1) {
      setQuizData(prev => ({
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1,
        timeLeft: getTimeForDifficulty(prev.difficulty),
        selectedAnswer: null,
        showResult: false
      }));
    } else {
      setCurrentScreen('result');
    }
  };

  const restartQuiz = () => {
    setCurrentScreen('home');
  };

  const showLeaderboard = () => {
    setCurrentScreen('leaderboard');
  };

  const saveScore = (name) => {
    const leaderboard = JSON.parse(localStorage.getItem('leaderboard') || '[]');
    const newEntry = {
      name,
      score: quizData.score,
      total: quizData.questions.length,
      category: quizData.category,
      difficulty: quizData.difficulty,
      date: new Date().toISOString()
    };
    leaderboard.push(newEntry);
    leaderboard.sort((a, b) => b.score - a.score);
    localStorage.setItem('leaderboard', JSON.stringify(leaderboard));
    showLeaderboard();
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <Home onStart={startQuiz} />;
      case 'quiz':
        return <Quiz quizData={quizData} onAnswerSelect={handleAnswerSelect} onTimeUp={nextQuestion} />;
      case 'result':
        return <Result quizData={quizData} onRestart={restartQuiz} onSaveScore={saveScore} onShowLeaderboard={showLeaderboard} />;
      case 'leaderboard':
        return <Leaderboard onBack={() => setCurrentScreen('home')} />;
      default:
        return <Home onStart={startQuiz} />;
    }
  };

  return (
    <div className="app">
      <button className="theme-toggle" onClick={toggleTheme}>
        {theme === 'light' ? '🌙' : '☀️'}
      </button>
      <div className="screen fade-in">
        {renderScreen()}
      </div>
    </div>
  );
}

export default App;
