import { useState } from 'react';
import '../styles/Home.css';

function Home({ onStart }) {
  const [category, setCategory] = useState('JavaScript');
  const [difficulty, setDifficulty] = useState('Easy');

  const handleStart = () => {
    onStart(category, difficulty);
  };

  return (
    <div className="home">
      <h1>Interactive Quiz App</h1>
      <div className="selection-group">
        <label htmlFor="category">Category:</label>
        <select id="category" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="JavaScript">JavaScript</option>
          <option value="HTML">HTML</option>
          <option value="CSS">CSS</option>
        </select>
      </div>
      <div className="selection-group">
        <label htmlFor="difficulty">Difficulty:</label>
        <select id="difficulty" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
          <option value="Easy">Easy</option>
          <option value="Medium">Medium</option>
          <option value="Hard">Hard</option>
        </select>
      </div>
      <button className="start-btn" onClick={handleStart}>Start Quiz</button>
    </div>
  );
}

export default Home;