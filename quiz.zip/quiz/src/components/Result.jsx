import { useState } from 'react';
import '../styles/Result.css';

function Result({ quizData, onRestart, onSaveScore, onShowLeaderboard }) {
  const [name, setName] = useState('');
  const [saved, setSaved] = useState(false);

  const percentage = Math.round((quizData.score / quizData.questions.length) * 100);

  const getMessage = () => {
    if (percentage >= 90) return { text: 'Excellent!', class: 'excellent' };
    if (percentage >= 70) return { text: 'Good!', class: 'good' };
    if (percentage >= 50) return { text: 'Average', class: 'average' };
    return { text: 'Needs Improvement', class: 'needs-improvement' };
  };

  const message = getMessage();

  const handleSave = () => {
    if (name.trim()) {
      onSaveScore(name.trim());
      setSaved(true);
    }
  };

  return (
    <div className="result">
      <h2>Quiz Completed!</h2>
      <div className="score">{quizData.score}/{quizData.questions.length}</div>
      <div className="percentage">{percentage}%</div>
      <div className={`message ${message.class}`}>{message.text}</div>
      {!saved && (
        <div className="name-input">
          <label>Enter your name: </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={20}
          />
          <button className="save-btn" onClick={handleSave} disabled={!name.trim()}>
            Save Score
          </button>
        </div>
      )}
      {saved && <p>Score saved! Check the leaderboard.</p>}
      <button className="restart-btn" onClick={onRestart}>Restart Quiz</button>
      <button className="restart-btn" onClick={onShowLeaderboard}>View Leaderboard</button>
    </div>
  );
}

export default Result;