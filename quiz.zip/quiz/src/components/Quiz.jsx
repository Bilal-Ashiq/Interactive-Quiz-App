import { useState, useEffect } from 'react';
import '../styles/Quiz.css';

function Quiz({ quizData, onAnswerSelect, onTimeUp }) {
  const [timeLeft, setTimeLeft] = useState(quizData.timeLeft);
  const [progress, setProgress] = useState(100);

  const currentQuestion = quizData.questions[quizData.currentQuestionIndex];

  // Reset timer when question changes or timeLeft prop changes
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    setTimeLeft(quizData.timeLeft);
    setProgress(100);
  }, [quizData.currentQuestionIndex, quizData.timeLeft]);

  useEffect(() => {
    if (timeLeft > 0 && !quizData.showResult) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          const newTime = prev - 1;
          setProgress((newTime / quizData.timeLeft) * 100);
          return newTime;
        });
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && !quizData.showResult) {
      onTimeUp();
    }
  }, [timeLeft, quizData.showResult, quizData.timeLeft, onTimeUp]);

  const handleAnswerClick = (index) => {
    if (!quizData.showResult) {
      onAnswerSelect(index);
    }
  };

  const getOptionClass = (index) => {
    if (!quizData.showResult) return 'option-btn';
    if (index === currentQuestion.correct) return 'option-btn correct';
    if (index === quizData.selectedAnswer && index !== currentQuestion.correct) return 'option-btn incorrect';
    return 'option-btn disabled';
  };

  return (
    <div className="quiz">
      <div className="timer">{timeLeft}s</div>
      <div className="progress-bar">
        <div className="progress-fill" style={{ width: `${progress}%` }}></div>
      </div>
      <div className="question">
        <h2>{currentQuestion.question}</h2>
        <div className="options">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              className={getOptionClass(index)}
              onClick={() => handleAnswerClick(index)}
              disabled={quizData.showResult}
            >
              {option}
            </button>
          ))}
        </div>
      </div>
      <div className="question-counter">
        Question {quizData.currentQuestionIndex + 1} of {quizData.questions.length}
      </div>
    </div>
  );
}

export default Quiz;