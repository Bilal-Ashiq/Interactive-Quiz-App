import { useState, useEffect } from 'react';
import '../styles/Leaderboard.css';

function Leaderboard({ onBack }) {
  const [leaderboard, setLeaderboard] = useState(() => {
    const stored = JSON.parse(localStorage.getItem('leaderboard') || '[]');
    return stored.slice(0, 5); // Top 5
  });

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    // Re-load leaderboard when component mounts (in case data was updated)
    const stored = JSON.parse(localStorage.getItem('leaderboard') || '[]');
    setLeaderboard(stored.slice(0, 5));
  }, []);

  return (
    <div className="leaderboard">
      <h2>Leaderboard</h2>
      {leaderboard.length > 0 ? (
        <ul className="leaderboard-list">
          {leaderboard.map((entry, index) => (
            <li key={index} className={`leaderboard-item ${index < 3 ? 'top' : ''}`}>
              <span>{index + 1}. {entry.name}</span>
              <span>{entry.score}/{entry.total} ({entry.category} - {entry.difficulty})</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="no-scores">No scores yet. Be the first to play!</p>
      )}
      <button className="back-btn" onClick={onBack}>Back to Home</button>
    </div>
  );
}

export default Leaderboard;