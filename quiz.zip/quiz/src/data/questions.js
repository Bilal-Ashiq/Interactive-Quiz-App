export const questions = {
  JavaScript: [
    {
      question: "What is the output of typeof null?",
      options: ["null", "object", "undefined", "boolean"],
      correct: 1
    },
    {
      question: "Which method adds an element to the end of an array?",
      options: ["push()", "pop()", "shift()", "unshift()"],
      correct: 0
    },
    {
      question: "What does '===' operator do?",
      options: ["Assigns value", "Compares value and type", "Compares value only", "Creates object"],
      correct: 1
    },
    {
      question: "Which keyword declares a block-scoped variable?",
      options: ["var", "let", "const", "function"],
      correct: 1
    },
    {
      question: "What is a closure in JavaScript?",
      options: ["A way to close a function", "A function with access to its outer scope", "A loop structure", "An error type"],
      correct: 1
    },
    {
      question: "Which array method creates a new array with results of calling a function?",
      options: ["forEach()", "map()", "filter()", "reduce()"],
      correct: 1
    },
    {
      question: "What is the purpose of 'use strict'?",
      options: ["Enables strict mode", "Imports modules", "Exports functions", "Creates classes"],
      correct: 0
    },
    {
      question: "Which object represents the browser's window?",
      options: ["document", "window", "navigator", "location"],
      correct: 1
    },
    {
      question: "What does JSON.parse() do?",
      options: ["Stringifies an object", "Parses a JSON string", "Creates a new object", "Validates JSON"],
      correct: 1
    },
    {
      question: "Which loop executes at least once?",
      options: ["for", "while", "do-while", "forEach"],
      correct: 2
    }
  ],
  HTML: [
    {
      question: "What does HTML stand for?",
      options: ["Hyper Text Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyperlink and Text Markup Language"],
      correct: 0
    },
    {
      question: "Which tag is used for the largest heading?",
      options: ["<h1>", "<h6>", "<p>", "<div>"],
      correct: 0
    },
    {
      question: "What is the correct way to create a hyperlink?",
      options: ["<a href='url'>text</a>", "<link url='text'>", "<href='url'>text</href>", "<url>text</url>"],
      correct: 0
    },
    {
      question: "Which attribute specifies an image's alternative text?",
      options: ["src", "alt", "title", "href"],
      correct: 1
    },
    {
      question: "What is the purpose of the <meta> tag?",
      options: ["To create metadata", "To style content", "To add scripts", "To define sections"],
      correct: 0
    },
    {
      question: "Which input type creates a checkbox?",
      options: ["text", "radio", "checkbox", "password"],
      correct: 2
    },
    {
      question: "What does the <br> tag do?",
      options: ["Creates a line break", "Creates a paragraph", "Creates a list", "Creates a table"],
      correct: 0
    },
    {
      question: "Which tag is used for unordered lists?",
      options: ["<ol>", "<ul>", "<li>", "<list>"],
      correct: 1
    },
    {
      question: "What is the correct HTML for creating a table row?",
      options: ["<tr>", "<td>", "<th>", "<table>"],
      correct: 0
    },
    {
      question: "Which attribute makes an input field required?",
      options: ["validate", "required", "mandatory", "needed"],
      correct: 1
    }
  ],
  CSS: [
    {
      question: "What does CSS stand for?",
      options: ["Cascading Style Sheets", "Computer Style Sheets", "Creative Style Sheets", "Colorful Style Sheets"],
      correct: 0
    },
    {
      question: "Which property changes text color?",
      options: ["font-color", "text-color", "color", "background-color"],
      correct: 2
    },
    {
      question: "What is the correct syntax for a CSS class selector?",
      options: [".classname", "#classname", "classname", "*classname"],
      correct: 0
    },
    {
      question: "Which property controls the space between elements?",
      options: ["margin", "padding", "border", "spacing"],
      correct: 0
    },
    {
      question: "What does 'flex' in CSS do?",
      options: ["Creates flexible layouts", "Adds flexibility to text", "Makes images responsive", "Controls font size"],
      correct: 0
    },
    {
      question: "Which unit is relative to the font size of the root element?",
      options: ["px", "em", "rem", "%"],
      correct: 2
    },
    {
      question: "What is the purpose of media queries?",
      options: ["To query the server", "To make responsive designs", "To add animations", "To import fonts"],
      correct: 1
    },
    {
      question: "Which property centers content horizontally?",
      options: ["text-align: center", "margin: auto", "float: center", "position: center"],
      correct: 1
    },
    {
      question: "What does 'z-index' control?",
      options: ["Text size", "Element stacking order", "Border width", "Background position"],
      correct: 1
    },
    {
      question: "Which pseudo-class targets hovered elements?",
      options: [":active", ":hover", ":focus", ":visited"],
      correct: 1
    }
  ]
};